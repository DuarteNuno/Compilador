module Main where

import Lexer
import Parser
import Interm  
import Control.Monad.State -- para correr computação State Count
import qualified Data.Map as Map -- para tabela de símbolos
 
main :: IO ()
main = do
    txt <- getContents      -- ler toda a entrada padrão 
    let stms = parser (alexScanTokens txt)   -- assumindo que parser retorna um Stm
    --print stms
    let code = evalState (transFunctotal Map.empty stms) (0,0)  -- correr a tradução começando com uma tabela vazia e contadores a zero
    print code  -- imprimir o código intermédio e terminar