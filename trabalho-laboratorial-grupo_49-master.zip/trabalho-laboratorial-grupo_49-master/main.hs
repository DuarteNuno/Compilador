module Main where

import Lexer
import Parser
--import Interm  
--import Control.Monad.State -- para correr computação State Count
--import qualified Data.Map as Map -- para tabela de símbolos
 
main :: IO ()
main = do
    txt <- getContents      -- ler toda a entrada padrão 
    let stm = parser (alexScanTokens txt)   -- assumindo que parser retorna um Stm
    print stm
    --let code = evalState (transStm Map.empty stm) (0,0)  -- correr a tradução começando com uma tabela vazia e contadores a zero
    --print code  -- imprimir o código intermédio e terminar