module Interm where

import Control.Monad.State
import Parser
import Lexer
import            Data.Map (Map)
import qualified  Data.Map as Map
import Data.Typeable


type Count = (Int,Int)
type Temp  = String
type Label = String
type Table = Map String String

data Instr = MOVE Temp Temp
           | MOVEI Temp Int
           | OP  BinOp Temp Temp Temp
           | OPI BinOp Temp Temp Int
           | LABEL Label
           | JUMP Label
           | COND Temp BinOp Temp Label Label
           deriving Show

newTemp  :: State Count Temp
newTemp  = do (temps,labels) <-get
              put (temps+1,labels)
              return ("t"++show temps)

newLabel :: State Count Label
newLabel = do (temps,labels) <-get
              put (temps,labels+1)
              return ("L"++show labels)

transExp :: Table -> Exp -> Temp -> State Count [Instr]
transExp tabl (Sent x) dest
    = do temp <- newTemp
         return ([MOVE dest temp])
        

transExp tabl (Num n) dest
  = return [MOVEI dest n ]


transExp tabl (Op op e1 e2) dest
    = do temp1 <- newTemp
         temp2 <- newTemp
         code1 <- transExp tabl e1 temp1
         code2 <- transExp tabl e2 temp2
         return (code1 ++ code2 ++ [OP op dest temp1 temp2])


transBloco :: Table -> Stm -> State Count [Instr]
transBloco tabl (Bloc [] )
    = return []

transBloco tabl (Bloc (stm:stms) )
    = do (code,_) <- transStm tabl stm
         code_ <- transBloco tabl (Bloc stms)
         return (code++code_)


transStm :: Table -> Stm -> State Count ([Instr],Table)

--atribuicao 
transStm tabl (Atrb var exp)
  = do temp  <- newTemp
       tempe <- newTemp
       code  <- transExp tabl exp temp
       return ((code++[MOVE temp tempe]),tabl)

--declaracao
transStm tabl (Decl type_ var)
    = do temp <- newTemp
         return ([MOVE temp var],(Map.insert var temp tabl))

--atribuicao e declaracao
transStm tabl (AtrDecl type_ var exp)
  = do (code1,tabln) <- transStm tabl (Decl type_ var)
       (code2,_) <- transStm tabln (Atrb var exp)
       return ((code1 ++ code2),tabln)

transStm tabl (If cond stm1)
    = do ltrue  <- newLabel
         lfalse <- newLabel
         code0  <- transCond tabl cond ltrue lfalse
         (code1,_)  <- transStm tabl stm1
         return (code0 ++ [LABEL ltrue ] ++ code1 ++ [LABEL lfalse],tabl)

transStm tabl (IfElse cond stm1 stm2)
    = do ltrue  <- newLabel
         lfalse <- newLabel
         lend   <- newLabel
         code0  <- transCond tabl cond ltrue lfalse
         (code1,_)  <- transStm tabl stm1
         (code2,_)  <- transStm tabl stm2
         return ((code0 ++ [LABEL ltrue] ++ code1 ++ [JUMP lend, LABEL lfalse] ++  code2 ++ [LABEL lend]),tabl)

transStm tabl (Bloc stms)
  = do code <- transBloco tabl (Bloc stms)
       return ((code),tabl)

--transStm tabl n = error $""++ show n

transCond :: Table -> Exp -> Label -> Label -> State Count [Instr]
transCond tabl (Boolean True) ltrue lfalse
    = do return ([JUMP ltrue])

transCond tabl (Boolean False) ltrue lfalse
    = do return ([JUMP lfalse])

transCond tabl (Not expb ) ltrue lfalse
    = do transCond tabl expb lfalse ltrue

transCond tabl (Op And exp1 exp2) ltrue lfalse
    = do label2 <- newLabel
         code1 <- transCond tabl exp1 label2 lfalse
         code2 <- transCond tabl exp2 ltrue lfalse
         return (code1 ++ [LABEL label2] ++ code2 )

transCond tabl (Op Or exp1 exp2) ltrue lfalse
    = do label2 <- newLabel
         code1 <- transCond tabl exp1 ltrue label2
         code2 <- transCond tabl exp2 ltrue lfalse
         return (code1 ++ [LABEL label2] ++ code2 )

transCond tabl exp ltrue lfalse
    = do t  <- newTemp
         --t0 <- newTemp
         code <- transExp tabl exp t
         --code0 <- [MOVEI t0 0]
         return (code ++ [COND t Different "0" ltrue lfalse])

transFunctotal :: Table -> [Func] -> State Count [Instr]
transFunctotal tabl []
    = return [] 

transFunctotal tabl (f1:fs) 
    = do code <- transFunc tabl f1
         code_ <- transFunctotal tabl fs
         return (code ++ code_)

transFunc :: Table -> Func -> State Count [Instr]
transFunc tabl (Fnc _ nome [] )
    = return []    

transFunc tabl (Fnc t nome (stm:stms) )
    = do (code,_) <- transStm tabl stm
         code_ <- transFunc tabl (Fnc t nome (stms) )
         return(code ++ code_)
