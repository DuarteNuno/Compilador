module Interm where

import Control.Monad.State
import AST
import            Data.Map (Map)
import qualified  Data.Map as Map


type Count = (Int,Int)
type Temp  = String
type Label = String
type Table = Map String String

data Instr = MOVE  Temp Temp
           | MOVEI Temp Int
           | OP  BinOp Temp Temp Temp
           | OPI BinOp Temp Temp Int
           | LABEL Label
           | JUMP Label
           | COND Temp BinOp Temp Label Label
           deriving Show

newTemp  :: State Count Temp 
newTemp  = do(temps,labels) <-get
            put (temps+1,labels)
            return ("t"++show temps)
newLabel :: State Count Label 
newLabel = do(temps,labels) <-get
            put (temps,labels+1)
            return ("L"++show labels)

transExp :: Table -> Exp -> Temp -> State Count [Instr]
transExp tabl (Sent x) dest
    = case Map.lookup x tabl of
    	Just temp -> retur [MOVE dest temp]
    	Nothing -> error "invalid variable"

transExp tabl (Num n) dest
   = return [MOVEI dest n]

transExp tabl (Op op e1 e2) dest
    = do temp1 <- newTemp
         temp2 <- newTemp
         code1 <- transExp tabl e1 temp1
         code2 <- transExp tabl e2 temp2
         retur (code1 ++ code2 ++ [OP op dest temp1 temp 2])

transStm :: Table -> Stm -> State Count [Instr]
transStm tabl (Assign var exp)
    = case Map.lookup var table of
    	Nothing -> error "undefined variable"
    	Just dest -> do temp <- newTemp
    	                code <- transExp
    	                return (code ++ [MOVE dest temp])

transStm tabl (If cond stm1)
    = do ltrue  <- newLabel
         lfalse <- newLabel
         code0  <- transCond tabl cond ltrue lfalse
         code1  <- transStm tabl stm1
         return (code0 ++ [LABEL ltrue ] ++ 
         	     code1 ++ [LABEL lfalse])

transStm tabl (IfElse cond stm1 stm2)
    = do ltrue  <- newLabel
         lfalse <- newLabel
         lend   <- newLabel
         code0  <- transCond tabl cond ltrue lfalse
         code1  <- transStm tabl stm1
         code2  <- transStm tabl stm2
         return (code0 ++ [LABEL ltrue] ++ 
         	     code1 ++ [JUMP lend, LABEL lfalse] ++  
         	     code2 ++ [LABEL lend])

transCond :: Table -> Exp -> Label -> Label -> State Count [Instr]
transCond tabl true ltrue lfalse
    = do return [JUMP ltrue]

transCond tabl false ltrue lfalse
    = do return [JUMP lfalse]

transCond tabl (Not expb ) ltrue lfalse
    = do transCond tabl expb lfalse ltrue






















